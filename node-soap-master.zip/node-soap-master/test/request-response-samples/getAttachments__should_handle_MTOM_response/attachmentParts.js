module.exports = [{
    body:Buffer.from("...binary data..."),
    headers:{
        "content-type": "image/tiff",
        "content-transfer-encoding": "binary"
    }
}];