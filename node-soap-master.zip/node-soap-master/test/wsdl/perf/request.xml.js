module.exports = '<ns1:orderRq xmlns:ns1="http://example.org/ns1" xmlns="http://example.org/ns1">' +
  '<ns1:itemRq><ns1:item>bread</ns1:item></ns1:itemRq>' +
  '</ns1:orderRq>';
